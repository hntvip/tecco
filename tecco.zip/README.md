"# tecco" 
